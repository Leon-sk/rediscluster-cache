This directory contains patches against the official
LZMA SDK that are needed to build PyLZMA.

Patch files are managed using quilt.
